productForm.jsp contains code to show error messages
and WEB-INF/lib contains JSTL
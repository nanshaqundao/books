 - add     <context:component-scan base-package="app04b.service"/>
 - add view method
 - add jstl jars
 - use c:url in ViewProduct.jsp for main.css
 - modify saveProduct to use redirect
 
 - need to discuss RedirectAttributes and FlashAttributes
 
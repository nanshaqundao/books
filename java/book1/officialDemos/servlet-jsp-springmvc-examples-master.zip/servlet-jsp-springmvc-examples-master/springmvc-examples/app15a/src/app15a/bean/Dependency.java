package app15a.bean;

public class Dependency {

}

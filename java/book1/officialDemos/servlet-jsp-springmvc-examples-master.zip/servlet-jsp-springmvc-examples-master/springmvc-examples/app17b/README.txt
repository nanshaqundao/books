Move config file to /WEB-INF/config
use viewResolver with prefix/suffix